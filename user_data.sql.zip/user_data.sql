-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2013 at 03:07 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `task_03`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE IF NOT EXISTS `user_data` (
  `id` int(4) NOT NULL,
  `name` varchar(30) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `roll_no` varchar(11) NOT NULL,
  `dept` varchar(45) NOT NULL,
  `email_id` varchar(35) NOT NULL,
  `clubsall` varchar(150) NOT NULL,
  `address` varchar(300) NOT NULL,
  `school` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`id`, `name`, `dob`, `gender`, `roll_no`, `dept`, `email_id`, `clubsall`, `address`, `school`, `password`) VALUES
(1, 'Juan John Mathews', '29-01-94', 'male', '4332577680', 'Computer Science and Engineering', 'juanjhn@gmail.com', 'delta+spider+ecell', 'House no:5,\r\nWellington Island,\r\nKochin,\r\nKerala-680631', 'Hari Sri Vidya Nidhi School,Thrissur', '708f1961ed4739eb4e797f5a30457ae9'),
(2, 'Ann Mary John', '02-06-97', 'female', '1234567890', 'N/A', 'annjohn@gmail.com', 'robotics+baha+dt', 'Qtr no:C-5,\r\nKerala Police Academy,\r\nR. V. Puram,\r\nKerala:-680690.', 'Hari Sri Vidya Nidhi School,Thrissur', '49e7dec59517a6509a08e8ceff515a1a'),
(7, 'Nilin Shamrith', '13-11-93', 'male', '0998734211', 'Architecture', 'nilin93@yahoo.co.in', 'delta+spider+robotics+baha', 'Quilon House,\r\nGandhi Nagar,\r\nMumbai:400036', 'Woodside School, Woodside', '23c2333e518a8f8907e1b64998b32b6a'),
(3, 'Gauri Pillai', '10-08-94', 'male', '2465368680', 'Juridical Science', 'gpshines@hotmail.com', 'delta+spider+robotics+baha', 'Theertham,\r\nShastri Nagar,\r\nAdyar,\r\nChennai,\r\nTamil Nadu:- 600020', 'Maharshi International Residential School,Adyar', '856b0799e5384cedcfa5e81e68af06cb'),
(4, 'James Philip', '03-12-92', 'male', '422438678', 'N/A', 'james_philip92@gmail.com', 'robotics+baha+dt', 'House no: 3\r\nDowning St.\r\nTexas, Houston.', 'Good Shepherd International School, Ooty, Ootacamund', '433f50461b4f54a8cd2d5e636f0bc6c2'),
(5, 'Amit Padjoshi', '14-05-95', 'male', '0987638680', 'Electronics and Communication Engg', 'amitpadjoshi_95@gmail.com', 'delta+spider+robotics+baha+dt+ecell', 'Quarter A-5,\r\nKEPA,RC Barracks,\r\nSrihallil,\r\nAndra Pradesh.', 'Loyola School, Snowden Road', '6d62166dce63e00d6652d99e4a7165d8'),
(6, 'Aashik Krishnan', '17-12-94', 'male', '2147483647', 'Chemical Engineering', 'aashik_krish@hotmail.com', 'robotics+baha+dt+ecell', 'Latheef House,\r\nBharghavi Nivas,\r\nBandra,\r\nMaharashtra.', 'Good Shepherd International School, Ooty, Ootacamund', '7a147dab40dba9b4c78e183f3d2137ae');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
